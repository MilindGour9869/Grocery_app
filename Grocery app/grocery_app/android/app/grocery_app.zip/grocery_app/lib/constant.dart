import 'package:flutter/cupertino.dart';

const Kpageviewtextstyle = TextStyle(
  fontSize: 20 , fontWeight: FontWeight.w700 ,
);