import 'package:flutter/material.dart';
class Homescreen extends StatelessWidget {
  static const String id= 'home-screen';
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.orange,
    );
  }
}
