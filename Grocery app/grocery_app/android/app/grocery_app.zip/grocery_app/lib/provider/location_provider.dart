import 'package:flutter/cupertino.dart';

class LocationProvider with ChangeNotifier{
   double Longitude;
   double latitude;
}