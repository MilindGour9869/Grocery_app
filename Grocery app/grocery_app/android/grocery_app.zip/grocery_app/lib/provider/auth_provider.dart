import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../screens/home_screen.dart';
import 'package:groceryapp/services/user_services.dart';

class AuthProvider with ChangeNotifier{
  String smsOtp;
  String verificationId;
  String error = '';
 FirebaseAuth _auth = FirebaseAuth.instance;
 UserServices _userServices = UserServices();

  Future<void> verifyphone(BuildContext context, String number)async{

    final PhoneVerificationCompleted verificationCompleted=(PhoneAuthCredential credential) async {
      // ANDROID ONLY!
      // Sign the user in (or link) with the auto-generated credential
      await _auth.signInWithCredential(credential);
    };

    final PhoneVerificationFailed  verificationFailed= (FirebaseAuthException e)async{
      print(e.code);
    };

    final PhoneCodeSent smsotpSend= (String verId, int resendToken) async {
      this.verificationId = verId;

      smsOtpDialog(context, number);
    };

try{
_auth.verifyPhoneNumber(
  phoneNumber: number,
  verificationCompleted: verificationCompleted,
  verificationFailed: verificationFailed,
  codeSent: smsotpSend,
  codeAutoRetrievalTimeout: (String verId) {
    this.verificationId=verId;
  },
);

}catch(e)
    {  print(e);
  }
}

Future<bool> smsOtpDialog(BuildContext context , String number){
    return showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: Column(
              children: [
                Text('Verification code'),
                SizedBox(height: 6,),
                Text('Enter 6 digit number as on sms ' , style: TextStyle(color: Colors.grey, fontSize: 12),)
              ],
            ),
            content: Container(
              height: 85,
              child:TextField(
                textAlign: TextAlign.center,
                keyboardType: TextInputType.phone,
                maxLength: 6,
                onChanged: (value){
                  this.smsOtp = value;
                },
              )
            ),

            actions:[
              TextButton(
                  onPressed: ()async{
                    try{
                      PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: verificationId, smsCode: smsOtp);
                      final User user =  (await _auth.signInWithCredential(credential)).user;

                      _createUser(id:user.uid , number: user.phoneNumber);


                      if(user!=null)
                        { //after login , destoring welcome screen becoz not come again after login
                          Navigator.of(context).pop();
                          Navigator.pushReplacementNamed(context, Homescreen.id);
                        }
                      else{
                        print('login failed \n');
                      }


                    }catch(e){
                     print(e.toString());
                     this.error='\n Invalid otp';
                     Navigator.of(context).pop();


                    }




                  },
                  child: Text('DONE'))
            ],
          );
        });
}
 void _createUser({String id , String number})
 {
   _userServices.createUserData({
     'id':id,
     'number':number,
   });
 }


}

